# Female sprite drafts

80 appearances: ten races, each base plus seven hybrid forms. All frames are 64×64. Direction columns: South, North, East, West.

Walk PNG: neutral, step A, step B rows; play 0,1,0,2 at 200 ms per phase. Walk DMI contains the same four-phase sequence.

Injury PNG/DMI: Normal, NoLeftArm, NoRightArm, NoArms, NoLeftLeg, NoRightLeg, NoLegs. Standing poses only. Injured walking, attacks, sleep, equipment fitting and live game integration remain separate work. No detached limb-piece assets are included.

Artwork is direct native AI editing of each female identity. Packing uses whole poses, nearest-neighbor sampling and transparent-fragment cleanup. Full source artwork, prompts and corrective poses are retained in the project folder and GOA Female Sprite Sources.zip.
